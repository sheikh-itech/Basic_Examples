/************************************************************************************************************
DHTML Blocked
Copyright (C) August 2010  DTHMLGoodies.com, Alf Magne Kalleland

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

Dhtmlgoodies.com., hereby disclaims all copyright interest in this script
written by Alf Magne Kalleland.

Alf Magne Kalleland, 2010
Owner of DHTMLgoodies.com

************************************************************************************************************/

if(!window.DG) {
	window.DG = {};
};


DG.BlockedDebug = new Class( {
	Extends : DG.Blocked,

	logPuzzleObject : function(renderTo) {
		var string = '{ difficulty : 1, bricks : [';

		var bricks = this.internal.currentPuzzle.bricks;
		for(var i=0;i<bricks.length;i++) {
			if(i) {
				string = string + ',';
			}
			string = string + '{'
			var started = false;
			for(var prop in bricks[i]){
				if(started) {
					string+=',';
				}
				string = string + prop + ':' + bricks[i][prop];
				started = true;
			}
			string = string + '}';
		}
		string = string + '] }';
		$(renderTo).set('value',string);
	},
	/* For creation of new puzzles */
	_showGrid : function() {
		for(var i=0;i<this.config.squares.x;i++) {
			for(var j=0;j<this.config.squares.x;j++) {
				var el = new Element('div');
				el.setStyles({
					position : 'absolute',
					'text-align' : 'center',
					left : i * this.config.squares.size,
					top : j * this.config.squares.size,
					width : this.config.squares.size,
					height : this.config.squares.size,
					'line-height' : this.config.squares.size
				});
				el.set('html', i + ',' + j);
				$(this.dom.canvas).adopt(el);
			}
		}

	},
	_addNewBrick : function(brick) {

		var bricks = this.internal.currentPuzzle.bricks;
		bricks[bricks.length] = brick;

		this._addBrick(brick, bricks.length-1);

	},
	scramble : function(countMoves, inSolveMode, returnWhenExceeding) {
		var d = new Date();
		var startTime = d.getTime();
		timeToUse = 6000;
		if(inSolveMode) {

			countMoves = 9999999;
		}
		if(!countMoves){
			countMoves = 100;
		}
		var bricks = this.internal.currentPuzzle.bricks;
		this.scrambleMode = true;
		indexOfEscapeKey = this.getIndexOfEscapeBrick();
		for(var i=0; i < countMoves; i++) {

			for (var j = 0; j < 2; j++) {
				var d2 = new Date();
				if(d2.getTime() - startTime > timeToUse) {
					console.info('escaping - too much time used ');
					console.info('Time used : ' + (d2.getTime() - startTime));
					this._scrambleSetNewPositions();
					return;
				}

				if (j == 1) {
					var brickIndex = indexOfEscapeKey;
				}
				else {
					var brickIndex = Math.floor(Math.random() * bricks.length);
				}

				var brick = bricks[brickIndex]

				if(returnWhenExceeding && i>returnWhenExceeding) {
					return returnWhenExceeding;
				}

				var direction = brick.width > brick.height ? 'horizontal' : 'vertical';
				this._setValidDragDropRange(brickIndex, direction);


				var min = this.dragDrop.validRange.min / this.config.squares.size;
				var max = this.dragDrop.validRange.max / this.config.squares.size;

				if (min != 0 || max != 0) {

					if (brickIndex == indexOfEscapeKey + 1000 && !inSolveMode) {
						rand = min;

					}
					else {
						var rand = 0;
						while (rand == 0) {
							var rand = Math.round(Math.random() * (max - min));
							rand += min;
						}
					}

					if (brickIndex == indexOfEscapeKey && inSolveMode) {
						if(bricks[indexOfEscapeKey].x + bricks[indexOfEscapeKey].width + max == this.config.squares.x) {
							// console.info('Time used : ' + (d2.getTime() - startTime));
							console.info('Moves used : ' + i);
							this._scrambleSetNewPositions();
							return i;
						}

					}

					if (direction == 'horizontal') {
						brick.x += rand;
					}
					else {
						brick.y += rand;

					}
				}
			}
		}


		this.scrambleMode = false;
		if (!returnWhenExceeding) {
			this._scrambleSetNewPositions();
		}
		// 'dg-brick' + index

			//console.info(brickIndex);
	},
	_scrambleSetNewPositions : function() {
		var bricks = this.internal.currentPuzzle.bricks;
		for(var i=0;i<bricks.length;i++) {
			var brick = bricks[i];
			var direction = brick.width > brick.height ? 'horizontal' : 'vertical';
			if (direction == 'horizontal') {
				$('dg-brick' + i).setStyle('left', brick.x * this.config.squares.size);
			}else{
				$('dg-brick' + i).setStyle('top', brick.y * this.config.squares.size);
			}
		}
	}

});