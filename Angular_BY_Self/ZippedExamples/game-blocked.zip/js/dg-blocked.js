/************************************************************************************************************
DHTML Blocked
Copyright (C) August 2010  DTHMLGoodies.com, Alf Magne Kalleland

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

Dhtmlgoodies.com., hereby disclaims all copyright interest in this script
written by Alf Magne Kalleland.

Alf Magne Kalleland, 2010
Owner of DHTMLgoodies.com

************************************************************************************************************/

if(!window.DG) {
	window.DG = {};
};


DG.Blocked = new Class( {
	Extends: Events,
	config : {
		squares : {
			x : 6,
			y : 6,
			size : 50,
			cls : 'dg-square',
			margin : 1
		}
	},
	strings : {
		record : 'Best: {0} moves'
	},
	validEvents : ['loadpuzzle'],
	difficultyLabels : {
		'0'	:	'Warm up',
		'1'	:  'Easy',
		'2'	:  'Easy',
		'3'	:  'Medium',
		'4'	:  'Medium',
		'5'	:  'Medium',
		'6'	:  'Hard',
		'7'	:  'Hard',
		'8'	:  'Hard',
		'9'	:  'Hardest'
	},
	urlController : 'blocked-controller.php',
	templatePuzzle : null,
	scrambleMode : false,
	showGrid : null,
	internal : {
		moveCount : 0,
		idCounter : 0,
		currentPuzzle : null,
		startUpPositions : null,
		numberOfPuzzlesInCollection : 0,
		puzzleIndex : 0,
		record : 'N/A',
		cookieName : 'cookie-game-blocked',
		isSolved : false
	},

	log : {
		userMoves : []
	},

	dom : {
		el : null,
		canvas : null,
		elLevel : null,
		elCurrentPuzzleNumber : null,
		elNumberOfPuzzles : null,
		elRecord : null,
		elMoves : null
	},
	dragDrop : {
		active : false,
		el : null,
		direction : 'horizontal',
		validRange : {	/* Maxmimum movement of a brick relative to start position. */
			min : 0,
			max : 0
		},
		start : {
			brick : {
				x: 0,
				y : 0
			},
			mouse: {
				x: 0,
				y: 0
			}
		}
	},
	initialize : function(config) {
		this.dom.el = config.el;
		this.dom.elLevel = config.elLevel;
		this.dom.elCurrentPuzzleNumber = config.elCurrentPuzzleNumber;
		this.dom.elNumberOfPuzzles = config.elNumberOfPuzzles;
		this.dom.elSolved = config.elSolved;
		this.dom.elRecord = config.elRecord;
		this.dom.elMoves = config.elMoves;

		if(config.urlController) {
			this.urlController = config.urlController;
		}
		if(config.templatePuzzle) {
			this.templatePuzzle = config.templatePuzzle;
		}
		if(config.listeners) {
			this._addEvents(config.listeners);
		}
		if(config.squareConfig) {
			this.config.squares = $merge(this.config.squares, config.squareConfig);

		}
		this.internal.puzzleIndex = config.puzzleIndex;
		this.showGrid = config.showGrid;
		this._createCanvas();
		this._getNumberOfPuzzlesInCollection();
		this._loadPuzzle();
	},

	_addEvents : function(listeners) {

		for(var listener in config.listeners) {
			if(this.validEvents.indexOf(listener)>=0) {
				this.addEvent(listener, config.listeners[listener]);
			}
		}

	},

	_getNumberOfPuzzlesInCollection : function() {
		var req = new Request({
			url: this.urlController,
			method : 'post',
			data : {
				getNumberOfPuzzles : '1'
			},
			onSuccess: function(JSONresponse){
				this.internal.numberOfPuzzlesInCollection = JSON.decode(JSONresponse).numPuzzlesInCollection;
				if(this.dom.elNumberOfPuzzles){
					$(this.dom.elNumberOfPuzzles).set('html', this.internal.numberOfPuzzlesInCollection);
				}
			}.bind(this)
		});
		req.send();
	},
	_getUniqueId : function() {
		this.internal.idCounter++;
		return 'dg-blocked-el-' + this.internal.idCounter;

	},
	_createCanvas : function() {

		var el = new Element('div');
		el.addClass('dg-blocked-canvas');
		el.setStyles({
			width : this.config.squares.x * this.config.squares.size,
			height : this.config.squares.x * this.config.squares.size
		});
		el.id = this._getUniqueId();
		this.dom.canvas = el.id;
		$(this.dom.el).adopt(el);

		$(this.dom.canvas).addEvent('mousemove', this._moveBrick.bind(this))


	},
	getFirstPuzzle : function() {
		this.internal.puzzleIndex = 0;
		this._loadPuzzle()

	},

	getLastPuzzle : function() {
		this.internal.puzzleIndex = this.internal.numberOfPuzzlesInCollection-1;
		this._loadPuzzle()
	},

	getNextPuzzle : function() {
		if(this.internal.puzzleIndex < this.internal.numberOfPuzzlesInCollection - 1) {
			this.internal.puzzleIndex++;
			this._loadPuzzle();
		}
	},

	getPreviousPuzzle : function() {

		if(this.internal.puzzleIndex>0) {
			this.internal.puzzleIndex --;
			this._loadPuzzle();
		}
	},
	getCurrentPuzzle : function() {
		this._loadPuzzle();
	},
	_loadPuzzle : function(puzzleIndex) {
		if(this.templatePuzzle) {
			puzzle = this.templatePuzzle;
			this.internal.currentPuzzle = puzzle;
			this._displayCurrentPuzzle();
		}else{
			requestData = {
				getPuzzle : '1',
				puzzleIndex : this.internal.puzzleIndex
			}

			var req = new Request({
				url: this.urlController,
				method : 'post',
				data : requestData,
				onSuccess: function(puzzleText){
					dataObject = JSON.decode(puzzleText);
					this.internal.puzzleIndex = dataObject.puzzleIndex;
					this.internal.isSolved = dataObject.isSolved;
					this.internal.record = dataObject.record;
					this.internal.currentPuzzle = dataObject.puzzle;
					this._displayCurrentPuzzle();
					this.fireEvent('loadpuzzle', this.internal.puzzleIndex);
				}.bind(this)
			});
			req.send();

		}
	},
	_clearUserLog : function() {
		this.log.userMoves.length = 0;
	},
	/** For debugging and puzzle making purpose only */
	loadFromText : function(puzzleText) {
		this.internal.currentPuzzle = JSON.decode(puzzleText);
		this._displayCurrentPuzzle();
	},
	createPuzzleMakerStartupPosition : function() {
		this.internal.currentPuzzle = {
			difficulty : 1,
			bricks : [
				{
					x : 1,
					y : 2,
					width : 2,
					height : 1,
					escape : 1
				}
			]

		}
		this._displayCurrentPuzzle();
	},
	reset : function() {
		this.internal.currentPuzzle = JSON.decode(this.internal.startUpPositions);
		this._displayCurrentPuzzle();
	},
	_displayCurrentPuzzle : function() {
		this._clearCanvas();
		this.internal.moveCount = 0;
		this._clearUserLog();

		if(this.dom.elCurrentPuzzleNumber){
			$(this.dom.elCurrentPuzzleNumber).set('html', (this.internal.puzzleIndex + 1));
		}
		if(this.dom.elRecord){
			$(this.dom.elRecord).set('html', this.internal.record);
		}
		if(this.dom.elSolved) {
			$(this.dom.elSolved).setStyle('display', this.internal.isSolved == '1' ? 'block' : 'none');
		}
		this._updateMoveCountInGui();
		this.internal.startUpPositions = JSON.encode(this.internal.currentPuzzle);

		if(this.showGrid) {
			this._showGrid();
		}
		if(this.dom.elLevel){
			$(this.dom.elLevel).set('html', this.difficultyLabels[this.internal.currentPuzzle.difficulty])
		}
		puzzle = this.internal.currentPuzzle;
		for(i=0;i<puzzle.bricks.length;i++) {
			if(!puzzle.bricks[i].height) {
				puzzle.bricks[i].height = 1;
			}
			if(!puzzle.bricks[i].width) {
				puzzle.bricks[i].width = 1;
			}
			this._addBrick(puzzle.bricks[i], i);
		}
	},

	_addBrick : function(brick, index) {
		var el = new Element('div');
		el.id = 'dg-brick' + index;
		el.addClass('dg-brick');
		el.addClass('dg-brick-' + brick.width + '-' + brick.height);
		if(brick.escape) {
			el.addClass('dg-brick-escape');
		}
		el.setProperty('brick-index', index);
		el.setStyles({
			position: 'absolute',
			cursor : 'pointer',
			left : brick.x * this.config.squares.size,
			top : brick.y * this.config.squares.size,
			margin : this.config.squares.margin,
			width : brick.width * this.config.squares.size - (this.config.squares.margin*2),
			height : brick.height * this.config.squares.size - (this.config.squares.margin*2),
			'z-index' : 100
		});
		el.addEvent('mousedown', this._grabBrick.bind(this));
		$(document.documentElement).addEvent('mouseup', this._releaseBrick.bind(this));

		$(this.dom.canvas).adopt(el);

	},
	_grabBrick : function(e) {
		this.dragDrop.start.mouse.x = e.client.x;
		this.dragDrop.start.mouse.y = e.client.y;
		this.dragDrop.active = true;

		var brickIndex = e.target.getProperty('brick-index');
		var brick = this.internal.currentPuzzle.bricks[brickIndex];
		this.dragDrop.direction = brick.width >= brick.height ? 'horizontal' : 'vertical';

		var position = e.target.getPosition(true);
		this.dragDrop.start.brick.x = this._getAsNumeric(e.target.getStyle('left'));
		this.dragDrop.start.brick.y = this._getAsNumeric(e.target.getStyle('top'));
		this.dragDrop.el = e.target.id;

		this._setValidDragDropRange(brickIndex, this.dragDrop.direction);

		return false;
	},
	_setValidDragDropRange : function(brickIndex, direction) {
		var brick = this.internal.currentPuzzle.bricks[brickIndex];

		var bricks = this.internal.currentPuzzle.bricks;

		if(direction == 'horizontal') {
			var key = 'x';
			var canvasSize = this.config.squares.x;
			var brickSize = brick.width;
		}else{
			var key = 'y';
			var canvasSize = this.config.squares.y;
			var brickSize = brick.height;
		}

		this.dragDrop.validRange.min = brick[key] * -1;
		this.dragDrop.validRange.max = (canvasSize - brickSize - brick[key]);

		for(var i=0;i<bricks.length;i++) {


			if (direction == 'horizontal') {
				if (bricks[i].y <= brick.y && (bricks[i].y + bricks[i].height) > brick.y) {
					if (bricks[i].x < brick.x) {
						this.dragDrop.validRange.min = Math.max(this.dragDrop.validRange.min, (brick.x - (bricks[i].x + bricks[i].width)) * -1);
					}
					if (bricks[i].x > brick.x) {
						this.dragDrop.validRange.max = Math.min(this.dragDrop.validRange.max, bricks[i].x - brick.x - brick.width);
					}
				}
			}else{
				if (bricks[i].x <= brick.x && (bricks[i].x+ bricks[i].width) > brick.x) {

					if (bricks[i].y < brick.y) {
						this.dragDrop.validRange.min = Math.max(this.dragDrop.validRange.min, (brick.y - (bricks[i].y + bricks[i].height)) * -1);
					}
					if (bricks[i].y > brick.y) {
						this.dragDrop.validRange.max = Math.min(this.dragDrop.validRange.max, bricks[i].y - brick.y - brick.height);
					}
				}

			}
		}

		this.dragDrop.validRange.min *= this.config.squares.size;
		this.dragDrop.validRange.max *= this.config.squares.size;


	},
	_getAsNumeric : function(value) {
		value = value + '';
		return value.replace(/[^0-9]/g,'')/1;
	},
	_moveBrick : function(e) {
		if(this.dragDrop.active) {

			if(this.dragDrop.direction == 'horizontal') {
				var cssKey = 'left';
				var objectKey = 'x';
			}else{
				var cssKey = 'top';
				var objectKey = 'y';
			}
			var offsetFromStart = (e.client[objectKey] - this.dragDrop.start.mouse[objectKey]);
			if(offsetFromStart < this.dragDrop.validRange.min) {
				offsetFromStart = this.dragDrop.validRange.min;
			}
			if(offsetFromStart > this.dragDrop.validRange.max) {
				offsetFromStart = this.dragDrop.validRange.max;
			}
			$(this.dragDrop.el).setStyle(cssKey, offsetFromStart + this.dragDrop.start.brick[objectKey]);
		}
		return false;
	},

	_releaseBrick : function(e) {
		if (this.dragDrop.active) {
			var brickIndex = $(this.dragDrop.el).getProperty('brick-index');

			var brick = this.internal.currentPuzzle.bricks[brickIndex];
			var originalCoordinates = {
				x : brick.x,
				y : brick.y
			}

			this.dragDrop.active = false;

			var leftPos = this._getNewPosition(this.dragDrop.el, 'left');
			var topPos = this._getNewPosition(this.dragDrop.el, 'top');
			$(this.dragDrop.el).setStyles( {
				left : leftPos,
				top : topPos
			});


			brick.x = leftPos / this.config.squares.size;
			brick.y = topPos / this.config.squares.size;

			if(originalCoordinates.x != brick.x || originalCoordinates.y != brick.y) {

				this.log.userMoves.push(
					{
						from : {
							x : originalCoordinates.x,
							y : originalCoordinates.y
						},
						to : {
							x : brick.x,
							y : brick.y
						}
					}
				);
				this.internal.moveCount++;
				this._updateMoveCountInGui();
			}
			if(brick.escape && !this.scrambleMode && brick.x + brick.width == this.config.squares.x) {
				this._finish();
			}

		}
	},

	_updateMoveCountInGui : function() {
		if(this.dom.elMoves) {
			$(this.dom.elMoves).set('html', this.internal.moveCount);
		}
	},

	_getNewPosition : function(el, cssKey) {
		el = $(el);
		return Math.round(this._getAsNumeric(el.getStyle(cssKey)) / this.config.squares.size) * this.config.squares.size;
	},

	_finish : function() {
		var req = new Request({
			url: this.urlController,
			method : 'post',
			data : {
				finished : '1',
				moveCount : this.internal.moveCount,
				logMoves : JSON.encode(this.log.userMoves),
				puzzleIndex : this.internal.puzzleIndex
			},
			onSuccess: function(content){
				this._getNextPuzzle();
			}.bind(this)
		});
		req.send();

	},
	_getNextPuzzle : function() {
		this.internal.puzzleIndex ++;
		this._clearCanvas();
		this._loadPuzzle();
	},
	_clearCanvas : function() {
		$(this.dom.canvas).set('html','');
	},

	getIndexOfEscapeBrick : function() {
		var bricks = this.internal.currentPuzzle.bricks;
		for(var i=0;i<bricks.length;i++) {
			if(bricks[i].escape){
				return i;
			}
		}
	}

});