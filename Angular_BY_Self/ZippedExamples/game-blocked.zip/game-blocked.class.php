<?php


// Connect to mysql db
include_once($_SERVER['DOCUMENT_ROOT']. '/config/connect.php');

class GameBlocked {

	private $puzzleIndex = 0;

	private $puzzles = array(
		"{ difficulty : 0, bricks : [{x:0,y:2,width:2,height:1,escape:1},{x:3,y:1,width:1,height:3},{x:2,y:0,width:2,height:1},{x:2,y:4,width:2,height:1},{x:1,y:4,width:1,height:2},{x:4,y:3,width:1,height:2}] }",
		"{ difficulty : 0, bricks : [{x:0,y:2,width:2,height:1,escape:1},{x:2,y:1,width:1,height:2},{x:1,y:0,width:2,height:1},{x:1,y:3,width:2,height:1},{x:0,y:3,width:1,height:2},{x:3,y:3,width:1,height:2},{x:3,y:1,width:1,height:2},{x:2,y:5,width:2,height:1},{x:1,y:4,width:1,height:2},{x:3,y:0,width:2,height:1},{x:0,y:0,width:1,height:2},{x:5,y:0,width:1,height:3},{x:4,y:4,width:1,height:2}] }",
		"{ difficulty : 0, bricks : [{x:3,y:2,width:2,escape:1,height:1},{x:5,y:1,width:1,height:3},{x:4,y:4,width:2,height:1},{x:4,y:5,width:2,height:1},{x:3,y:3,width:1,height:3}] }",
		"{ difficulty : 0, bricks : [{x:1,y:2,width:2,height:1,escape:1},{x:5,y:0,width:1,height:3},{x:3,y:1,width:1,height:2},{x:4,y:4,width:2,height:1},{x:2,y:3,width:2,height:1},{x:2,y:0,width:1,height:2},{x:4,y:2,width:1,height:2},{x:0,y:0,width:2,height:1},{x:2,y:4,width:1,height:2},{x:1,y:4,width:1,height:2}] }",
		"{ difficulty : 1, bricks : [{x:1,y:2,width:2,height:1,escape:1},{x:0,y:0,width:1,height:3},{x:3,y:1,width:1,height:2},{x:2,y:3,width:2,height:1},{x:1,y:3,width:1,height:2},{x:0,y:5,width:2,height:1},{x:2,y:0,width:2,height:1},{x:1,y:0,width:1,height:2},{x:4,y:0,width:1,height:3},{x:5,y:0,width:1,height:3},{x:4,y:3,width:2,height:1},{x:4,y:4,width:2,height:1},{x:0,y:3,width:1,height:2}] }",
		"{ difficulty : 1, bricks : [{x:0,y:2,width:2,height:1,escape:1},{x:2,y:1,width:1,height:2},{x:0,y:0,width:3,height:1},{x:1,y:3,width:2,height:1},{x:0,y:3,width:1,height:2},{x:0,y:5,width:2,height:1},{x:3,y:3,width:1,height:2},{x:3,y:0,width:1,height:2},{x:2,y:5,width:3,height:1},{x:4,y:1,width:1,height:2},{x:4,y:0,width:2,height:1}] }",
		"{ difficulty : 1, bricks : [{x:3,y:2,width:2,height:1,escape:1},{x:5,y:1,width:1,height:3},{x:3,y:4,width:3,height:1},{x:2,y:3,width:1,height:2},{x:2,y:0,width:2,height:1},{x:1,y:2,width:2,height:1},{x:1,y:3,width:1,height:2},{x:4,y:0,width:1,height:2},{x:4,y:5,width:2,height:1},{x:2,y:1,width:2,height:1}] }",
		"{ difficulty : 1, bricks : [{x:3,y:2,width:2,height:1,escape:1},{x:5,y:1,width:1,height:2},{x:4,y:0,width:2,height:1},{x:3,y:0,width:1,height:2},{x:2,y:1,width:1,height:3},{x:4,y:3,width:2,height:1},{x:3,y:3,width:1,height:2},{x:4,y:4,width:1,height:2},{x:2,y:5,width:2,height:1},{x:1,y:3,width:1,height:3},{x:1,y:1,width:1,height:2}] }",
		"{ difficulty : 1, bricks : [{x:0,y:2,width:2,height:1,escape:1},{x:2,y:0,width:1,height:3},{x:5,y:0,width:1,height:3},{x:4,y:3,width:2,height:1},{x:0,y:3,width:1,height:2},{x:1,y:3,width:2,height:1},{x:3,y:3,width:1,height:2},{x:1,y:5,width:3,height:1},{x:4,y:4,width:1,height:2}] }",
		"{ difficulty : 1, bricks : [{x:0,y:2,width:2,height:1,escape:1},{x:5,y:1,width:1,height:3},{x:4,y:1,width:1,height:3},{x:4,y:0,width:2,height:1},{x:4,y:4,width:2,height:1},{x:3,y:4,width:1,height:2},{x:2,y:2,width:1,height:2},{x:2,y:1,width:2,height:1},{x:2,y:0,width:2,height:1},{x:1,y:4,width:2,height:1}] }",
		"{ difficulty : 1, bricks : [{x:0,y:2,width:2,height:1,escape:1},{x:5,y:0,width:1,height:3},{x:4,y:3,width:2,height:1},{x:3,y:1,width:2,height:1},{x:3,y:3,width:1,height:3},{x:0,y:3,width:1,height:2},{x:2,y:3,width:1,height:2},{x:1,y:3,width:1,height:2}] }",
		"{ difficulty : 1, bricks : [{x:0,y:2,width:2,height:1,escape:1},{x:2,y:2,width:1,height:3},{x:0,y:5,width:3,height:1},{x:5,y:1,width:1,height:3},{x:3,y:4,width:1,height:2},{x:4,y:4,width:2,height:1}] }",
		"{ difficulty : 1, bricks : [{x:1,y:2,width:2,height:1,escape:1},{x:3,y:0,width:1,height:3},{x:4,y:0,width:1,height:3},{x:3,y:3,width:3,height:1},{x:1,y:0,width:2,height:1},{x:2,y:3,width:1,height:2},{x:4,y:5,width:2,height:1},{x:1,y:1,width:2,height:1},{x:0,y:0,width:1,height:2},{x:3,y:4,width:2,height:1}] }",
		"{ difficulty : 1, bricks : [{x:0,y:2,width:2,height:1,escape:1},{x:5,y:1,width:1,height:3},{x:4,y:1,width:1,height:3},{x:4,y:0,width:2,height:1},{x:4,y:4,width:2,height:1},{x:3,y:4,width:1,height:2},{x:2,y:2,width:1,height:2},{x:2,y:1,width:2,height:1},{x:2,y:0,width:2,height:1},{x:1,y:4,width:2,height:1},{x:0,y:3,width:1,height:2}] }",
		"{ difficulty : 1, bricks : [{x:3,y:2,width:2,height:1,escape:1},{x:5,y:1,width:1,height:3},{x:4,y:0,width:1,height:2},{x:2,y:0,width:2,height:1},{x:4,y:4,width:2,height:1},{x:3,y:4,width:1,height:2},{x:2,y:1,width:1,height:3},{x:0,y:0,width:1,height:2},{x:1,y:4,width:2,height:1},{x:4,y:5,width:2,height:1},{x:0,y:3,width:2,height:1},{x:0,y:5,width:2,height:1}] }",
		"{ difficulty : 1, bricks : [{x:0,y:2,width:2,height:1,escape:1},{x:2,y:1,width:1,height:2},{x:0,y:0,width:3,height:1},{x:1,y:3,width:2,height:1},{x:0,y:3,width:1,height:2},{x:3,y:3,width:1,height:3},{x:3,y:1,width:3,height:1},{x:0,y:5,width:3,height:1},{x:3,y:0,width:3,height:1},{x:4,y:3,width:1,height:2},{x:5,y:3,width:1,height:3}] }",
		// Minimum : 24
		"{ difficulty : 1, bricks : [{x:1,y:2,width:2,height:1,escape:1},{x:0,y:3,width:3,height:1},{x:3,y:0,width:1,height:3},{x:0,y:4,width:1,height:2},{x:1,y:4,width:2,height:1},{x:3,y:4,width:2,height:1},{x:4,y:0,width:2,height:1},{x:4,y:5,width:2,height:1},{x:5,y:3,width:1,height:2},{x:4,y:1,width:2,height:1},{x:0,y:0,width:2,height:1}] }",

		"{ difficulty : 2, bricks : [{x:1,y:2,width:2,height:1,escape:1},{x:3,y:1,width:1,height:2},{x:2,y:0,width:2,height:1},{x:1,y:0,width:1,height:2},{x:4,y:0,width:1,height:2},{x:2,y:3,width:2,height:1},{x:1,y:3,width:1,height:2},{x:0,y:5,width:2,height:1},{x:4,y:3,width:1,height:2},{x:4,y:5,width:2,height:1},{x:0,y:1,width:1,height:3},{x:5,y:2,width:1,height:2}] }",
		"{ difficulty : 2, bricks : [{x:1,y:2,width:2,height:1,escape:1},{x:3,y:1,width:1,height:2},{x:3,y:0,width:2,height:1},{x:5,y:0,width:1,height:3},{x:3,y:3,width:3,height:1},{x:2,y:3,width:1,height:2},{x:0,y:5,width:3,height:1},{x:3,y:4,width:2,height:1},{x:0,y:0,width:1,height:3},{x:4,y:1,width:1,height:2},{x:1,y:0,width:2,height:1}] }",
		"{ difficulty : 2, bricks : [{x:1,y:2,width:2,height:1,escape:1},{x:3,y:2,width:1,height:3},{x:1,y:5,width:3,height:1},{x:0,y:4,width:1,height:2},{x:2,y:1,width:2,height:1},{x:4,y:0,width:1,height:2},{x:4,y:2,width:1,height:2},{x:4,y:4,width:2,height:1},{x:4,y:5,width:2,height:1},{x:0,y:3,width:2,height:1},{x:0,y:1,width:1,height:2},{x:0,y:0,width:2,height:1},{x:2,y:0,width:2,height:1}] }",
		"{ difficulty : 2, bricks : [{x:0,y:2,width:2,height:1,escape:1},{x:2,y:2,width:1,height:3},{x:2,y:5,width:3,height:1},{x:5,y:2,width:1,height:3},{x:1,y:0,width:2,height:1},{x:4,y:0,width:2,height:1},{x:3,y:2,width:1,height:2},{x:3,y:0,width:1,height:2},{x:0,y:0,width:1,height:2},{x:0,y:3,width:1,height:2},{x:1,y:4,width:1,height:2},{x:4,y:1,width:2,height:1},{x:4,y:2,width:1,height:2}] }",
		"{ difficulty : 2, bricks : [{x:1,y:2,width:2,height:1,escape:1},{x:3,y:1,width:1,height:3},{x:1,y:4,width:3,height:1},{x:5,y:2,width:1,height:3},{x:0,y:4,width:1,height:2},{x:0,y:3,width:2,height:1},{x:2,y:0,width:2,height:1},{x:1,y:0,width:1,height:2},{x:2,y:5,width:2,height:1},{x:4,y:1,width:2,height:1},{x:4,y:2,width:1,height:2},{x:4,y:4,width:1,height:2},{x:0,y:0,width:1,height:2}] }",

		// Moves : 90+

		// Minimum move time: 100 +
		"{ difficulty : 3, bricks : [{x:3,y:2,width:2,height:1,escape:1},{x:5,y:1,width:1,height:3},{x:4,y:0,width:2,height:1},{x:3,y:0,width:1,height:2},{x:4,y:4,width:2,height:1},{x:3,y:4,width:1,height:2},{x:1,y:2,width:1,height:2},{x:0,y:5,width:2,height:1},{x:2,y:0,width:1,height:2},{x:2,y:4,width:1,height:2},{x:2,y:3,width:2,height:1}] }",
		"{ difficulty : 3, bricks : [{x:1,y:2,width:2,height:1,escape:1},{x:0,y:0,width:1,height:3},{x:3,y:2,width:1,height:3},{x:2,y:5,width:2,height:1},{x:1,y:4,width:1,height:2},{x:4,y:4,width:1,height:2},{x:1,y:3,width:2,height:1},{x:4,y:3,width:2,height:1},{x:2,y:1,width:2,height:1},{x:2,y:0,width:2,height:1},{x:5,y:0,width:1,height:2}] }",
		"{ difficulty : 3, bricks : [{x:0,y:2,width:2,height:1,escape:1},{x:5,y:1,width:1,height:3},{x:4,y:0,width:2,height:1},{x:4,y:4,width:2,height:1},{x:3,y:4,width:1,height:2},{x:3,y:0,width:1,height:2},{x:2,y:3,width:2,height:1},{x:1,y:3,width:1,height:2},{x:4,y:1,width:1,height:2},{x:0,y:5,width:3,height:1},{x:2,y:1,width:1,height:2},{x:4,y:5,width:2,height:1},{x:0,y:3,width:1,height:2}] }",
		"{ difficulty : 3, bricks : [{x:1,y:2,width:2,height:1,escape:1},{x:3,y:1,width:1,height:3},{x:2,y:0,width:2,height:1},{x:1,y:0,width:1,height:2},{x:2,y:4,width:2,height:1},{x:1,y:4,width:1,height:2},{x:4,y:4,width:1,height:2},{x:0,y:3,width:2,height:1},{x:4,y:3,width:2,height:1},{x:0,y:0,width:1,height:3},{x:5,y:4,width:1,height:2}] }",
		"{ difficulty : 3, bricks : [{x:2,y:2,width:2,height:1,escape:1},{x:4,y:1,width:1,height:2},{x:4,y:0,width:2,height:1},{x:3,y:0,width:1,height:2},{x:5,y:1,width:1,height:3},{x:4,y:4,width:2,height:1},{x:4,y:5,width:2,height:1},{x:3,y:4,width:1,height:2},{x:0,y:4,width:1,height:2},{x:1,y:4,width:1,height:2},{x:0,y:3,width:2,height:1},{x:2,y:0,width:1,height:2}] }",
		"{ difficulty : 3, bricks : [{x:1,y:2,width:2,height:1,escape:1},{x:1,y:1,width:2,height:1},{x:3,y:1,width:2,height:1},{x:3,y:2,width:1,height:2},{x:4,y:2,width:1,height:2},{x:2,y:3,width:1,height:2},{x:5,y:0,width:1,height:3},{x:3,y:4,width:3,height:1},{x:0,y:3,width:1,height:3},{x:1,y:5,width:2,height:1},{x:3,y:5,width:2,height:1},{x:0,y:0,width:2,height:1},{x:3,y:0,width:2,height:1}] }",
		"{ difficulty : 3, bricks : [{x:1,y:2,width:2,height:1,escape:1},{x:1,y:3,width:2,height:1},{x:3,y:3,width:2,height:1},{x:0,y:3,width:1,height:2},{x:3,y:0,width:1,height:3},{x:4,y:4,width:2,height:1},{x:4,y:0,width:2,height:1},{x:3,y:5,width:3,height:1},{x:4,y:1,width:1,height:2},{x:5,y:1,width:1,height:2},{x:0,y:0,width:2,height:1},{x:0,y:1,width:2,height:1},{x:1,y:4,width:2,height:1}] }",
		"{ difficulty : 3, bricks : [{x:1,y:2,width:2,height:1,escape:1},{x:1,y:0,width:2,height:1},{x:3,y:0,width:2,height:1},{x:5,y:0,width:1,height:3},{x:3,y:1,width:1,height:2},{x:4,y:1,width:1,height:2},{x:4,y:3,width:2,height:1},{x:4,y:4,width:2,height:1},{x:4,y:5,width:2,height:1},{x:2,y:3,width:1,height:2},{x:1,y:3,width:1,height:2},{x:2,y:5,width:2,height:1},{x:0,y:1,width:1,height:2}] }",
		"{ difficulty : 3, bricks : [{x:1,y:2,width:2,height:1,escape:1},{x:5,y:0,width:1,height:3},{x:4,y:0,width:1,height:3},{x:2,y:3,width:3,height:1},{x:4,y:4,width:2,height:1},{x:4,y:5,width:2,height:1},{x:2,y:4,width:1,height:2},{x:3,y:4,width:1,height:2},{x:2,y:0,width:2,height:1},{x:2,y:1,width:2,height:1},{x:0,y:1,width:1,height:3}] }",
		"{ difficulty : 3, bricks : [{x:3,y:2,width:2,height:1,escape:1},{x:5,y:1,width:1,height:3},{x:4,y:4,width:2,height:1},{x:3,y:3,width:1,height:2},{x:3,y:5,width:3,height:1},{x:3,y:0,width:3,height:1},{x:2,y:0,width:1,height:3},{x:1,y:3,width:2,height:1},{x:1,y:4,width:2,height:1},{x:0,y:0,width:1,height:2}] }",
		"{ difficulty : 3, bricks : [{x:1,y:2,width:2,height:1,escape:1},{x:3,y:0,width:1,height:3},{x:4,y:0,width:2,height:1},{x:5,y:1,width:1,height:3},{x:4,y:4,width:2,height:1},{x:4,y:5,width:2,height:1},{x:2,y:3,width:1,height:2},{x:1,y:0,width:2,height:1},{x:0,y:0,width:1,height:3},{x:0,y:3,width:2,height:1}] }",
		"{ difficulty : 3, bricks : [{x:3,y:2,width:2,height:1,escape:1},{x:5,y:0,width:1,height:3},{x:4,y:3,width:2,height:1},{x:3,y:3,width:1,height:2},{x:2,y:1,width:1,height:2},{x:2,y:0,width:3,height:1},{x:4,y:5,width:2,height:1},{x:2,y:5,width:2,height:1},{x:1,y:4,width:1,height:2},{x:0,y:3,width:2,height:1},{x:0,y:0,width:1,height:2},{x:0,y:4,width:1,height:2}] }",
		"{ difficulty : 3, bricks : [{x:0,y:2,width:2,height:1,escape:1},{x:3,y:1,width:1,height:3},{x:1,y:5,width:3,height:1},{x:4,y:3,width:1,height:2},{x:5,y:3,width:1,height:2},{x:2,y:4,width:2,height:1},{x:3,y:0,width:3,height:1},{x:0,y:0,width:1,height:2},{x:1,y:0,width:1,height:2},{x:4,y:1,width:1,height:2},{x:2,y:1,width:1,height:2},{x:1,y:3,width:2,height:1},{x:4,y:5,width:2,height:1}] }",

		"{ difficulty : 4, bricks : [{x:2,y:2,width:2,escape:1,height:1},{x:5,y:1,width:1,height:3},{x:3,y:4,width:3,height:1},{x:4,y:2,width:1,height:2},{x:2,y:1,width:3,height:1},{x:1,y:0,width:1,height:2},{x:4,y:5,width:2,height:1},{x:2,y:3,width:1,height:2},{x:0,y:4,width:2,height:1}] }",
		"{ difficulty : 4, bricks : [{x:0,y:2,width:2,height:1,escape:1},{x:0,y:0,width:1,height:2},{x:1,y:0,width:2,height:1},{x:4,y:0,width:2,height:1},{x:2,y:1,width:1,height:3},{x:1,y:5,width:3,height:1},{x:3,y:3,width:1,height:2},{x:4,y:4,width:2,height:1},{x:0,y:3,width:2,height:1},{x:5,y:1,width:1,height:3},{x:3,y:1,width:1,height:2}] }",
		"{ difficulty : 1, bricks : [{x:0,y:2,width:2,height:1,escape:1},{x:5,y:1,width:1,height:3},{x:4,y:4,width:2,height:1},{x:4,y:5,width:2,height:1},{x:3,y:3,width:1,height:2},{x:2,y:5,width:2,height:1},{x:1,y:4,width:1,height:2},{x:2,y:0,width:1,height:3},{x:1,y:3,width:2,height:1},{x:4,y:0,width:2,height:1},{x:3,y:1,width:2,height:1},{x:0,y:0,width:1,height:2},{x:0,y:3,width:1,height:2}] }",

		// Moves 200 +
		"{ difficulty : 5, bricks : [{x:2,y:2,width:2,height:1,escape:1},{x:4,y:1,width:1,height:3},{x:3,y:0,width:3,height:1},{x:5,y:2,width:1,height:2},{x:4,y:4,width:2,height:1},{x:3,y:4,width:1,height:2},{x:0,y:5,width:3,height:1},{x:1,y:2,width:1,height:2},{x:0,y:1,width:2,height:1},{x:2,y:0,width:1,height:2},{x:0,y:2,width:1,height:2}] }",
		"{ difficulty : 5, bricks : [{x:2,y:2,width:2,height:1,escape:1},{x:4,y:1,width:1,height:3},{x:3,y:4,width:3,height:1},{x:4,y:0,width:2,height:1},{x:3,y:0,width:1,height:2},{x:2,y:4,width:1,height:2},{x:2,y:3,width:2,height:1},{x:1,y:1,width:1,height:2},{x:1,y:0,width:2,height:1},{x:0,y:5,width:2,height:1}] }",
		"{ difficulty : 5, bricks : [{x:1,y:2,width:2,height:1,escape:1},{x:3,y:1,width:1,height:2},{x:3,y:0,width:3,height:1},{x:2,y:0,width:1,height:2},{x:0,y:2,width:1,height:2},{x:0,y:1,width:2,height:1},{x:0,y:4,width:2,height:1},{x:1,y:3,width:3,height:1},{x:4,y:3,width:1,height:2},{x:4,y:5,width:2,height:1},{x:3,y:4,width:1,height:2},{x:0,y:5,width:2,height:1}] }",
		"{ difficulty : 5, bricks : [{x:1,y:2,width:2,escape:1,height:1},{x:0,y:0,height:3,width:1},{x:3,y:0,width:2,height:1},{x:4,y:1,height:2,width:1},{x:1,y:0,height:2,width:1},{x:2,y:0,height:2,width:1},{x:0,y:3,width:3,height:1},{x:3,y:4,height:2,width:1},{x:5,y:0,height:3,width:1},{x:0,y:5,width:2,height:1},{x:2,y:4,height:2,width:1},{x:4,y:4,width:2,height:1},{x:4,y:5,width:2,height:1}] }",
		"{ difficulty : 5, bricks : [{x:0,y:2,width:2,height:1,escape:1},{x:2,y:1,width:1,height:3},{x:1,y:0,width:2,height:1},{x:0,y:0,width:1,height:2},{x:1,y:4,width:2,height:1},{x:0,y:4,width:1,height:2},{x:2,y:5,width:2,height:1},{x:4,y:4,width:1,height:2},{x:3,y:3,width:2,height:1},{x:3,y:0,width:1,height:2},{x:4,y:1,width:2,height:1},{x:5,y:2,width:1,height:2}] }",
		"{ difficulty : 5, bricks : [{x:0,y:2,width:2,height:1,escape:1},{x:3,y:1,width:1,height:3},{x:2,y:0,width:2,height:1},{x:2,y:4,width:2,height:1},{x:1,y:4,width:1,height:2},{x:4,y:3,width:1,height:2},{x:1,y:0,width:1,height:2},{x:4,y:5,width:2,height:1},{x:0,y:3,width:2,height:1},{x:4,y:0,width:2,height:1},{x:5,y:1,width:1,height:2},{x:0,y:0,width:1,height:2}] }",
		"{ difficulty : 5, bricks : [{x:3,y:2,width:2,height:1,escape:1},{x:5,y:1,width:1,height:3},{x:4,y:0,width:2,height:1},{x:3,y:4,width:3,height:1},{x:2,y:4,width:1,height:2},{x:3,y:3,width:2,height:1},{x:1,y:3,width:2,height:1},{x:3,y:0,width:1,height:2},{x:0,y:5,width:2,height:1},{x:0,y:3,width:1,height:2},{x:0,y:2,width:2,height:1},{x:2,y:1,width:1,height:2},{x:1,y:0,width:2,height:1}] }",

		// Moves 350 ++
		"{ difficulty : 7, bricks : [{x:0,y:2,width:2,height:1,escape:1},{x:2,y:1,width:1,height:3},{x:1,y:4,width:2,height:1},{x:0,y:4,width:1,height:2},{x:0,y:3,width:2,height:1},{x:1,y:5,width:2,height:1},{x:3,y:0,width:3,height:1},{x:3,y:1,width:1,height:2},{x:4,y:1,width:1,height:2},{x:3,y:4,width:1,height:2},{x:4,y:5,width:2,height:1},{x:5,y:3,width:1,height:2}] }",
		"{ difficulty : 7, bricks : [{x:1,y:2,width:2,height:1,escape:1},{x:3,y:1,width:1,height:3},{x:2,y:4,width:2,height:1},{x:3,y:0,width:2,height:1},{x:2,y:0,width:1,height:2},{x:1,y:3,width:1,height:2},{x:0,y:5,width:3,height:1},{x:4,y:4,width:1,height:2},{x:4,y:3,width:2,height:1},{x:0,y:1,width:1,height:3},{x:5,y:1,width:1,height:2},{x:0,y:0,width:2,height:1}] }",
		"{ difficulty : 7, bricks : [{x:1,y:2,width:2,height:1,escape:1},{x:4,y:0,width:1,height:3},{x:4,y:3,width:2,height:1},{x:3,y:2,width:1,height:2},{x:2,y:1,width:2,height:1},{x:1,y:0,width:1,height:2},{x:3,y:4,width:2,height:1},{x:2,y:3,width:1,height:2},{x:1,y:5,width:2,height:1},{x:3,y:5,width:2,height:1},{x:0,y:1,width:1,height:3}] }",
		"{ difficulty : 7, bricks : [{x:1,y:2,width:2,height:1,escape:1},{x:5,y:1,width:1,height:3},{x:2,y:4,width:3,height:1},{x:3,y:0,width:3,height:1},{x:4,y:5,width:2,height:1},{x:2,y:5,width:2,height:1},{x:1,y:4,width:1,height:2},{x:3,y:1,width:1,height:2},{x:4,y:1,width:1,height:2},{x:2,y:0,width:1,height:2},{x:0,y:3,width:2,height:1},{x:0,y:1,width:1,height:2},{x:3,y:3,width:2,height:1}] }",

		// Moves 800 +
		"{ difficulty : 8, bricks : [{x:0,y:2,width:2,height:1,escape:1},{x:2,y:2,width:1,height:3},{x:0,y:5,width:3,height:1},{x:3,y:4,width:1,height:2},{x:3,y:3,width:2,height:1},{x:5,y:1,width:1,height:3},{x:4,y:4,width:2,height:1},{x:4,y:0,width:2,height:1},{x:3,y:0,width:1,height:2},{x:4,y:1,width:1,height:2},{x:1,y:0,width:1,height:2},{x:0,y:3,width:1,height:2}] }",
		"{ difficulty : 8, bricks : [{x:0,y:2,width:2,height:1,escape:1},{x:2,y:1,width:1,height:3},{x:1,y:0,width:2,height:1},{x:0,y:0,width:1,height:2},{x:1,y:4,width:2,height:1},{x:0,y:3,width:1,height:2},{x:0,y:5,width:2,height:1},{x:3,y:4,width:1,height:2},{x:3,y:0,width:1,height:2},{x:3,y:3,width:2,height:1},{x:5,y:3,width:1,height:2},{x:4,y:1,width:2,height:1},{x:4,y:4,width:1,height:2}] }",
		"{ difficulty : 8, bricks : [{x:0,y:2,width:2,height:1,escape:1},{x:2,y:0,width:1,height:3},{x:1,y:3,width:2,height:1},{x:3,y:3,width:1,height:2},{x:3,y:5,width:3,height:1},{x:3,y:1,width:1,height:2},{x:3,y:0,width:2,height:1},{x:0,y:3,width:1,height:2},{x:5,y:0,width:1,height:3},{x:1,y:4,width:2,height:1}] }",
		"{ difficulty : 8, bricks : [{x:0,y:2,width:2,height:1,escape:1},{x:0,y:4,width:1,height:2},{x:1,y:0,width:2,height:1},{x:3,y:0,width:2,height:1},{x:5,y:0,width:1,height:3},{x:3,y:1,width:1,height:2},{x:4,y:3,width:2,height:1},{x:2,y:1,width:1,height:3},{x:2,y:5,width:3,height:1},{x:3,y:3,width:1,height:2},{x:1,y:4,width:2,height:1}] }",
		"{ difficulty : 8, bricks : [{x:2,y:2,width:2,height:1,escape:1},{x:0,y:1,width:1,height:3},{x:1,y:3,width:1,height:2},{x:0,y:0,width:2,height:1},{x:4,y:0,width:2,height:1},{x:4,y:1,width:1,height:3},{x:5,y:1,width:1,height:3},{x:4,y:4,width:2,height:1},{x:0,y:5,width:2,height:1},{x:4,y:5,width:2,height:1},{x:2,y:0,width:1,height:2},{x:3,y:4,width:1,height:2},{x:2,y:3,width:2,height:1}] }",

		// Moves 1500 +
		"{ difficulty : 9, bricks : [{x:1,y:2,width:2,escape:1,height:1},{x:0,y:0,height:3,width:1},{x:3,y:0,width:2,height:1},{x:4,y:1,height:2,width:1},{x:1,y:0,height:2,width:1},{x:2,y:0,height:2,width:1},{x:0,y:3,width:3,height:1},{x:3,y:2,height:2,width:1},{x:5,y:0,height:3,width:1},{x:0,y:5,width:2,height:1},{x:2,y:4,height:2,width:1},{x:4,y:4,width:2,height:1},{x:4,y:5,width:2,height:1}] }",
		"{ difficulty : 9, bricks : [{x:1,y:2,width:2,escape:1,height:1},{x:0,y:2,height:3,width:1},{x:3,y:0,width:2,height:1},{x:4,y:1,height:2,width:1},{x:1,y:3,height:2,width:1},{x:2,y:0,height:2,width:1},{x:2,y:3,width:3,height:1},{x:3,y:4,height:2,width:1},{x:5,y:1,height:3,width:1},{x:0,y:5,width:2,height:1},{x:2,y:4,height:2,width:1},{x:4,y:4,width:2,height:1},{x:4,y:5,width:2,height:1}] }",
		"{ difficulty : 9, bricks : [{x:3,y:2,width:2,escape:1,height:1},{x:0,y:3,height:3,width:1},{x:1,y:0,width:2,height:1},{x:4,y:0,height:2,width:1},{x:1,y:1,height:2,width:1},{x:2,y:1,height:2,width:1},{x:3,y:3,width:3,height:1},{x:3,y:4,height:2,width:1},{x:5,y:0,height:3,width:1},{x:1,y:5,width:2,height:1},{x:2,y:3,height:2,width:1},{x:4,y:4,width:2,height:1},{x:4,y:5,width:2,height:1}] }",
		"{ difficulty : 9, bricks : [{x:3,y:2,width:2,escape:1,height:1},{x:0,y:3,height:3,width:1},{x:1,y:0,width:2,height:1},{x:4,y:0,height:2,width:1},{x:1,y:1,height:2,width:1},{x:2,y:1,height:2,width:1},{x:3,y:3,width:3,height:1},{x:3,y:4,height:2,width:1},{x:5,y:0,height:3,width:1},{x:1,y:5,width:2,height:1},{x:2,y:3,height:2,width:1},{x:4,y:4,width:2,height:1},{x:4,y:5,width:2,height:1}] }",
		"{ difficulty : 9, bricks : [{x:0,y:2,width:2,height:1,escape:1},{x:0,y:3,width:1,height:2},{x:3,y:1,width:1,height:2},{x:3,y:3,width:1,height:2},{x:4,y:3,width:2,height:1},{x:5,y:0,width:1,height:3},{x:1,y:4,width:2,height:1},{x:2,y:5,width:3,height:1},{x:2,y:1,width:1,height:3},{x:0,y:0,width:2,height:1},{x:2,y:0,width:2,height:1}] }",
		"{ difficulty : 9, bricks : [{x:0,y:2,width:2,height:1,escape:1},{x:2,y:0,width:1,height:3},{x:5,y:0,width:1,height:3},{x:4,y:3,width:2,height:1},{x:0,y:3,width:1,height:2},{x:1,y:3,width:2,height:1},{x:3,y:3,width:1,height:2},{x:1,y:5,width:3,height:1},{x:4,y:4,width:1,height:2},{x:3,y:0,width:2,height:1}] }"

	);

	const COOKIE_NAME = 'game-blocked-session';

	public function GameBlocked() {

	}

	public function getCountPuzzles() {
		return count($this->puzzles);
	}
	public function getPuzzleByIndex($index) {
		if($index >= count($this->puzzles)){
			$index = count($this->puzzles)-1;
		}
		return $this->puzzles[$index];
	}

	public function getCurrentPuzzle() {
		return $this->getPuzzleByIndex($this->getCurrentPuzzleIndex());
	}

	public function getSessionId() {
		if(isset($_COOKIE[self::COOKIE_NAME])) {
			return $_COOKIE[self::COOKIE_NAME];
		}else{
			$cookieValue = $this->getNewCookieName();
			if(!headers_sent()) {
				setcookie(self::COOKIE_NAME, $cookieValue, time()+ 60*60*24*600, '/' );
			}else{
				?>
				<script type="text/javascript">
				try{
					Cookie.write('<?php echo self::COOKIE_NAME; ?>', '<?php echo $cookieValue; ?>', {
						duration: 600,
						path : '/'
					});
				}catch(e) {
					alert(e.message);
				}
				</script>
				<?php
			}
			return $cookieValue;


		}
	}


	private function getNewCookieName() {
		$ret = '';
		$string = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVXYZ';
		for($i=0;$i<32;$i++) {
			$ret .= substr($string, rand(0, strlen($string)-1), 1);
		}
		$ret.=date("YmdHis");
		return $ret;
	}

	public function getCurrentPuzzleIndex() {
		$sessionId = $this->getSessionId();
		$res = mysql_query("select currentPuzzle from gameBlocked_User where sessionID = '" . $sessionId . "'");
		if($row = mysql_fetch_array($res)) {
			return $row['currentPuzzle'];
		}else{
			mysql_query("insert into gameBlocked_User(sessionID, currentPuzzle)values('$sessionId',0)") or die(mysql_error());
			return 0;
		}
	}

	public function increasePuzzleIndex() {
		mysql_query("update gameBlocked_User set currentPuzzle = currentPuzzle + 1 where sessionID = '" . $this->getSessionId() . "'");
		$this->puzzleIndex ++;
	}

	public function logUserResults($countMoves, $moves, $puzzleIndex) {
		$countMoves = preg_replace("/[^0-9]/s", "", $countMoves);
		$puzzleIndex = preg_replace("/[^0-9]/s", "", $puzzleIndex);
		$moves = preg_replace("/[^0-9a-z{},]/si", "", $moves);
		mysql_query("insert into gameBlocked_UserSolution(sessionID, puzzleIndex, moveCount, moves, theDate)values('" . $this->getSessionId(). "','". $puzzleIndex . "','". $countMoves . "','". $moves . "','". date("Y-m-d H:i:s"). "')") or die(mysql_error());
	}

	public function isSolved($puzzleIndex) {
		$res = mysql_query("select ID from gameBlocked_UserSolution where puzzleIndex = '$puzzleIndex' and sessionID='". $this->getSessionId() . "'");
		if($row = mysql_fetch_row($res)) {
			return 1;
		}else{
			return 0;
		}
	}
}


?>