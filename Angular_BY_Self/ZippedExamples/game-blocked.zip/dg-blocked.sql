create table gameBlocked_User (
	ID int auto_increment not null primary key,
	sessionID varchar(255),
	currentPuzzle int
);

create table gameBlocked_UserSolution (
	ID int auto_increment not null primary key,
	sessionID varchar(255),
	puzzleIndex int,
	theDate datetime,
	moveCount int,
	moves text
);


create index userSolutionpuzzle on gameBlocked_UserSolution(puzzleIndex);
