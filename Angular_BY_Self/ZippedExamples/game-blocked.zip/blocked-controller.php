<?php
include("game-blocked.class.php");

$blockedObject = new GameBlocked();



if(isset($_POST['getPuzzle'])) {
	if(isset($_POST['puzzleIndex'])) {
		$puzzle = $blockedObject->getPuzzleByIndex($_POST['puzzleIndex']);
		$puzzleIndex = $_POST['puzzleIndex'];
	}else{
		$puzzle = $blockedObject->getCurrentPuzzle();
		$puzzleIndex = $blockedObject->getCurrentPuzzleIndex();
	}

	$json = '{
		puzzleIndex : ' . $puzzleIndex .',
		isSolved : ' . $blockedObject->isSolved($puzzleIndex) . ',
		puzzle : ' . $puzzle . '

	}';
	echo $json;
	exit;
}

if(isset($_POST['getNumberOfPuzzles'])) {
	echo '{ numPuzzlesInCollection: ' . $blockedObject->getCountPuzzles() . '}';
	exit;
}



if(isset($_POST['finished'])) {
	echo $_POST['moveCount'];

	$blockedObject->logUserResults($_POST['moveCount'], $_POST['logMoves'], $_POST['puzzleIndex']);
	$blockedObject->increasePuzzleIndex();
	exit;
}
?>