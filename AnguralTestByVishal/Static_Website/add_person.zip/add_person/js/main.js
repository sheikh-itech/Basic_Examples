"use strict";
function start()
{
	var myObj = JSON.parse(localStorage.getItem("user")) || [];
	var newHTML = [];
	newHTML.push("<ul id='list'>");
	for(var i = 0;i<myObj.length; i++){
		newHTML.push("<li class='div' onclick='find("+i+");'><a href='#/"+myObj[i].name+"'><h3>Customer</h3><p>"+myObj[i].name+"</p><p>"+myObj[i].loc+"</p><p>"+myObj[i].email+"</p></a></li>");
		
	};
	newHTML.push('</ul>');
	document.getElementById("user").innerHTML =newHTML;
};
function addInfo(){

	var flag = true;

	var name = document.getElementById('name').value;
	var loc = document.getElementById('loc').value;
	var email = document.getElementById('email').value;
	//alert(name+'--'+loc+'--'+email);
	var myObj = JSON.parse(localStorage.getItem("user")) || [];
		for(var i=0;i<myObj.length;i++){
			if(name === myObj[i].name){ 				
				
				flag = false;
				
				alert('User Already Exist ! Choose Another Name');
				return false;
			}
		}
		var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
        if(!re.test(email))
		{
				flag = false;
				alert('Email is not valid');
		}
		if(!/^[a-zA-Z\s]+$/.test(name))
		{
				flag = false;
				alert('Name shuld not contain numbers');
		};
		if(flag){
			myObj.push({
				'name': name,
				'loc': loc,
				'email': email			
			});
			localStorage.setItem('user', JSON.stringify(myObj));	
			location.reload();
		};
		
		
};
function find($index){
	var myObj = JSON.parse(localStorage.getItem("user")) || [];
	document.getElementById("name1").innerHTML ="&nbsp;&nbsp;&nbsp;&nbsp;Name : "+myObj[$index].name;
	document.getElementById("loc1").innerHTML ="<span class='glyphicon glyphicon-map-marker'></span>&nbsp;&nbsp;Location : "+myObj[$index].loc;
	document.getElementById("email1").innerHTML ="<span class='glyphicon glyphicon-envelope'></span>&nbsp;&nbsp;Email : "+myObj[$index].email;
	$('#flag').hide();
};
/*   un-used right now but can use to filter
function search(){
	var filter = $("#search").val();
	
	if(filter) {
          // this finds all links in a list that contain the input,
          // and hide the ones not containing the input while showing the ones that do
          $(list).find("a:not(:Contains(" + filter + "))").parent().slideUp();
          $(list).find("a:Contains(" + filter + ")").parent().slideDown();
        } else {
          $(list).find("li").slideDown();
        }
        return false;
};*/

$("#search")
      .change( function () {
        var filter = $("#search").val();
        if(filter) {
          // this finds all links in a list that contain the input,
          // and hide the ones not containing the input while showing the ones that do
          $(list).find("a:not(:Contains(" + filter + "))").parent().slideUp();
          $(list).find("a:Contains(" + filter + ")").parent().slideDown();
        } else {
          $(list).find("li").slideDown();
        }
        return false;
      })
    .keyup( function () {
        // fire the above change event after every letter
        $("#search").change();
    });