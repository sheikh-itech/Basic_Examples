var app = angular.module('libraryApp', ['ngRoute','examApp']);
app.config(function($routeProvider) {
    $routeProvider  
      .when('/', {
        templateUrl: "exam/login.html",
		controller: 'examCtrl'
      })
      .when('/register', {
        templateUrl: "exam/register.html",
		controller: 'examCtrl'
      })
      .when('/login', {
        templateUrl: "exam/login.html",
		controller: 'examCtrl'
      })
      .when('/examHome', {
        templateUrl: "exam/examHome.html",
		controller: 'examCtrl'
      })
      .when('/exam', {
        templateUrl: "exam/exam.html",
		controller: 'examController'
      })
      .when('/admin', {
        templateUrl: "exam/admin.html",
		controller: 'adminCtrl'
      })
      .when('/trainer', {
        templateUrl: "exam/trainer.html",
		controller: 'trainerCtrl'
      })
      .when('/admin', {
        templateUrl: "exam/admin.html",
		controller: 'adminCtrl'
      })
	 .otherwise({
        template: "<p style='color:red;margin-left:25%;'><big>Welcome to online exam system<big></p>"
      });
});
app.controller('examCtrl',['$scope', '$location', function ($scope, $location){
	
	$scope.reg_warning = false;
	$scope.login_warning = false;
	$scope.log_warning = false;
	$scope.reg_success = false;
	$scope.testListCond = '';
	
	$scope.var_test_list = false;

	var users = localStorage.getItem('users');
	var users = (localStorage.getItem('users')!==null) ? JSON.parse(users) : [{name:'admin',uname:'admin',utype:'Admin',pass:'admin',con:012345}];
               localStorage.setItem('users', JSON.stringify(users));

	$scope.register = function() {

     if(localStorage.getItem('admin') != null) {   
		 
		var myUsers = JSON.parse(localStorage.getItem("users"));
        var flag = true;
		for(var i = 0;i < myUsers.length; i++) {
			if(myUsers[i].uname === $scope.user.username)
			{
				flag = false;
			}
		}
		if(flag)  {
			myUsers.push({
				name: $scope.user.name,
				uname: $scope.user.username,
				utype: $scope.user.type,
				pass: $scope.user.pass,
				con: $scope.user.contact
			});
				localStorage.setItem('users', JSON.stringify(myUsers));
				$scope.reg_success = true;
				$scope.user = {};
		}else $scope.reg_warning = true;
	 }else alert('Please login first.');
    };   
    $scope.login = function() {
    	$scope.login = false;
		var myUsers = JSON.parse(localStorage.getItem("users"));
		
		for(var i = 0; i < myUsers.length; i++){
			
			if((myUsers[i].uname === $scope.user.username)&&(myUsers[i].pass === $scope.user.password)&&(myUsers[i].utype === $scope.user.type)){

				if($scope.user.type === 'Admin'){
        			$location.path("/admin");
        			localStorage.setItem('admin', $scope.user.username);
        		}
        		else if($scope.user.type === 'Trainer'){
        			$location.path("/trainer");
        			localStorage.setItem('trainer', $scope.user.username);
        		}
        		else if($scope.user.type === 'Trainee'){
        			localStorage.setItem('trainee', $scope.user.username);
        			//$scope.trainee = $scope.user.username;
        			//alert($scope.trainee);
        			$location.path("/examHome");        			
        		}
				$scope.login = true;
			}
		}
		if(!$scope.login) $scope.log_warning = true;
		$scope.user = {};
    	
    }; 
    $scope.getTest = function(){
    	
    	var name = localStorage.getItem('trainee');
		var testlist = JSON.parse(localStorage.getItem("testlist"));
		var currentTest = [];
		
		for(var i = 0; i < testlist.length; i++){
			if(testlist[i].username === name) {
				currentTest.push(testlist[i]);
			}
		}
		if(currentTest.length > 0) {
			$scope.testList = currentTest;
			$scope.var_test_list = true;
		}else $scope.testListCond = "You don't have any test write now or login if not yet ?";
            /*localStorage.removeItem('name');*/
    };
}]);
app.controller('adminCtrl',['$scope', '$location', function ($scope, $location){
	
	$scope.updt_warning = false;//
	$scope.updt_success = false;//
	$scope.all_user_list = false;//
	$scope.allUserDetailSuccess = '';
	$scope.allUserDetailError = '';
	$scope.user_updated = false;
	$scope.user_update = false;//
	$scope.allUserDetail = [];
	$scope.userDetail = [];
	
	$scope.update = function() {
	  if(localStorage.getItem('admin') != null) {
		  
        var myUsers = JSON.parse(localStorage.getItem("users"));
        var flag = true;
		for(var i = 0;i < myUsers.length; i++) {
			if(myUsers[i].uname === $scope.userDetail.uname)
			{
				myUsers[i].name = $scope.userDetail.name;
				myUsers[i].utype = $scope.userDetail.utype;
				myUsers[i].pass = $scope.userDetail.pass;
				myUsers[i].con = $scope.userDetail.con;			
			}
		}		
		localStorage.setItem('users', JSON.stringify(myUsers));
		$scope.getAllUsersList();
	  }else alert('Please login first.');
    };
    $scope.findDetails = function($index){
      if(localStorage.getItem('admin') != null) {

    	var myUsers = JSON.parse(localStorage.getItem("users"));

            $scope.userDetail = myUsers[$index];
            $scope.user_update = true;
            $scope.all_user_list = false;
            
            $scope.var_find = false;
            $scope.var_updt = true;
            if($scope.userDetail === null) $scope.find_fail = 'Some server problem occured please try later.';
            //localStorage.removeItem('name');
	  }else alert('Please login first.');
    };
    $scope.getAllUsersList = function(){
      if(localStorage.getItem('admin') != null) {

    	$location.path('/admin');
    	var myUsers = JSON.parse(localStorage.getItem("users"));
			if(myUsers.length > 0){
				$scope.allUserDetail = myUsers;
				$scope.all_user_list = true;
				$scope.user_update = false;
			}else $scope.allUserDetailSuccess = "Recently you don't have any registered user.";
            //localStorage.removeItem('name');
		
			if(myUsers === null) $scope.allUserDetailError = 'Some server problem occured please try later.';
	  }else alert('Please login first.');
    };
    $scope.deleteUser = function($index){
      if(localStorage.getItem('admin') != null) {	

		var myUsers = JSON.parse(localStorage.getItem("users"));
		myUsers.splice($index,1);
		localStorage.setItem('users', JSON.stringify(myUsers));
		$scope.getAllUsersList();
	  }else alert('Please login first.');
    };
    $scope.logOut = function(){
    	localStorage.removeItem('admin');
    };
}]);
app.controller('trainerCtrl',['$scope', '$location', function ($scope, $location){
    
	$scope.var_test = false;
	$scope.save_test = false;
	$scope.var_test_list = false;
	$scope.var_test_result = false;
	
	$scope.persons = {};
	$scope.setTest = function() {
	  if(localStorage.getItem('trainer') != null) {
		  
		$scope.var_test_list = false;
		$scope.var_test_result = false;
		$scope.var_test_result = false;
		var myUsers = JSON.parse(localStorage.getItem("users"));
		var myArr = [];
		for(var i = 0; i < myUsers.length; i++) {
			if(myUsers[i].utype === 'Trainee') {
				myArr.push({uname:myUsers[i].uname});
			}
		}
		
            $scope.persons = myArr;
            $scope.var_test = true;
	  }else alert('Please login first.');
		 		
    };
    $scope.saveTest = function() {
      if(localStorage.getItem('trainer') != null) {		
		  
    	$scope.var_test_list = false;
    	$scope.var_test_result = false;
    	$scope.var_test_result = false;

		var testlist = localStorage.getItem('testlist');
		var testlist = (localStorage.getItem('testlist')!==null) ? JSON.parse(testlist) : [];
		localStorage.setItem('testlist', JSON.stringify(testlist));
		//alert($scope.user.username+'--'+$scope.user.testname+'--'+$scope.user.filename);/*
		testlist.push({
			username: $scope.user.username,
			testname: $scope.user.testname,
			filename: $scope.user.filename
		});
		$scope.save_test = true;
        localStorage.setItem('testlist', JSON.stringify(testlist));        
    	$scope.user = {};
	  }else alert('Please login first.');
    };
    $scope.getTestList = function() {
	  if(localStorage.getItem('trainer') != null) {		

		$scope.var_test = false;
		$scope.var_test_result = false;
		//var testlist = JSON.parse(localStorage.getItem("testlist"));

            $scope.testList = JSON.parse(localStorage.getItem("testlist"));
            $scope.var_test_list = true;
            $scope.var_test_result = false; 
	  }else alert('Please login first.');
    };
    $scope.deleteTest = function($index){
      if(localStorage.getItem('trainer') != null) {	

    	$scope.var_test = false;
		$scope.var_test_result = false;

		var testlist = JSON.parse(localStorage.getItem("testlist"));

			testlist.splice($index,1);
            $scope.testList = testlist;
            $scope.var_test_list = true;
            $scope.var_test_result = false;

	   localStorage.setItem('testlist', JSON.stringify(testlist));    
	  }else alert('Please login first.');
    };
    $scope.getTestResult = function(){    
		
		if(localStorage.getItem('trainer') != null) {

            $scope.testResult = JSON.parse(localStorage.getItem("answer"));
            
            $scope.var_test_list = false;
            $scope.var_test = false;
            $scope.var_test_result = true;
		}else alert('Please login first.');
    };
    $scope.deleteTestResult = function($index){

    	if(localStorage.getItem('trainer') != null) {

    	var myAnswer = JSON.parse(localStorage.getItem("answer"));
		myAnswer.splice($index,1);
		localStorage.setItem('answer', JSON.stringify(myAnswer));

            $scope.testResult = myAnswer;
            
            $scope.var_test_list = false;
            $scope.var_test = false;
            $scope.var_test_result = true;
		}else alert('Please login first.');
    };
    $scope.logOut = function(){
    	localStorage.removeItem('trainer');
    };
}]);