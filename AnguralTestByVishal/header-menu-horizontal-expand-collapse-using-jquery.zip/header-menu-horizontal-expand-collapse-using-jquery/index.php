<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Horizontal Expand Collapse Using jQuery</title>
 <script src="//code.jquery.com/jquery-1.10.2.js"></script>
  <script src="//code.jquery.com/ui/1.11.2/jquery-ui.js"></script>

<script type = "text/javascript" language = "javascript" > $(document).ready(function (e) {
     $(".header-menu-list .btn-expand").click(function (e) {
		$('.collapsible').toggle("slide", {
            direction: "right"
        }, 2000);
     });
 });</script>
<style type="text/css">
.header-menu-list {background: #EBEBEB;padding: 10px;overflow: hidden;}
.header-menu-list .btn-expand {float: right;background: url("expand.png") center no-repeat; width:32px;height:32px;cursor:pointer;}
.collapsible{position:absolute;right:50px;top:25px;display:none;}
.collapsible ul{list-style:none;padding:0px;margin:0px;float:right;}
.collapsible ul li{list-style:none;display:inline-block;padding-right:15px;}
</style>
</head>
<body>
<div class="header-menu-list">
	<div class="btn-expand"></div>
	<div class="collapsible">
	<ul>
	<li>Home</li>
	<li>About</li>	
	<li>Product</li>	
	<li>Services</li>	
	<li>Contact</li>	
	</ul>
	</div>
</div>

</body>
</html>
