$('#flexi_form_start1').click(function() {
                introJs().start().oncomplete(function() {
                    window.location.href = 'complete.html';
                }).onexit(function() {
                    window.location.href = 'index.html';
                }).onbeforechange(function(targetElement) {
                    

          

                });
            });

$('#flexi_form_start2').click(function() {
                introJs().start().oncomplete(function() {
                    window.location.href = 'complete.html';
                }).onexit(function() {
                    window.location.href = 'index.html';
                }).onbeforechange(function(targetElement) {
                                   });
            });
